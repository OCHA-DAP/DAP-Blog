Copy and Rename the default.pot file to xx_XX.po where the 'xx' is the
locale code for the language to translate to, and the 'XX' is the 
country code, e.g. for french: fr_FR.po

Edit the po file with an editor like poEdit (http://www.poedit.net/) to do the desired translations and 
save the xx_XX.mo file in this directory so that WordPress and whatever translation plugin
you're using is be able to locate it.

Enjoy!