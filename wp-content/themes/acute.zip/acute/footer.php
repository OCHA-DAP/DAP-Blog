<?php /* Footer */
 
$options = get_option('bean_theme');
 
?>

</div><!-- END .row-->

</section>

<?php if (is_404()) { } else { //HIDE FOOTER FOR 404 ?>	

	<?php if ( isset( $options['footer_layout'] ) ) { $layout = $options['footer_layout'];

		  if ( $layout == 'fullwidth') { ?>

			<footer id="footer" class="animated BeanFadeIn">

				<div class="row">
					<div class="twelve columns hide-for-small left">
						<div class="eight columns hide-for-small left">
							<nav id="navigation" role="navigation">
							<div class="container">
							<div id="primary-nav" class="main_menu">
									<?php
		  								$args = array(
		  								    'container' 	=> '',
		  								    'menu_id' => 'footer-menu',
		  								    'menu_class' => 'sf-menu main-menu',
		  									'theme_location' => 'main-menu',
		  									'after' => '<span class="nav-sep">|</span>',
		  								);
		  								wp_nav_menu( apply_filters( 'radium_main_menu_args', $args ) );
		  							 ?>
		  					</div>
		  					</div>
		  					</nav>

		  							 <p> HUMANITARIAN DATA EXCHANGE BETA   v0.3.0 </p>
		  				</div>

		  				<div class="one columns hide-for-small center">
		  					<img src="wp-content/themes/acute/assets/images/cc_logo.png" />
		  				</div>
		  				<div class="three columns hide-for-small right">
		  					Except where otherwise noted, content on this site is licensed under a Creative Commons Attribution 4.0 International license.
						</div><!-- END .footer-fullwidth -->


					</div><!-- END .twelve columns -->
				</div><!-- END .row -->

			</footer><!-- END #footer -->






			<?php } if ( $layout == 'split') { ?>

			<footer id="footer" class="animated BeanFadeIn">

				<div class="row">  		 	

					<div class="five columns">

						<?php do_action('bean_colophon'); ?>

					</div><!-- END .five columns -->

					<div class="seven columns">

						<?php if ( !dynamic_sidebar( 'Footer' ) ): ?><?php endif; ?>

					</div><!-- END .seven columns -->				 		
					
				</div><!-- END .row -->
				
			</footer><!-- END #footer -->	 			
				
			<?php } if ( $layout == 'fullwidth_extra') { ?>
			
			<footer id="footer" class="animated BeanFadeIn">
			
				<div class="row">  
				
					<div class="twelve columns">
					
						<div class="footer-fullwidth">	
						
							<?php do_action('bean_colophon'); ?>

						</div><!-- END .footer-fullwidth -->	

					</div><!-- END .twelve columns -->

				</div><!-- END .row -->

			</footer><!-- END #footer -->


			<?php } if ( $layout == 'split_extra') { ?>

				<footer id="footer" class="animated BeanFadeIn">

					<div class="row">

						<div class="five columns">

							<?php do_action('bean_colophon'); ?>

						</div><!-- END .five columns -->

						<div class="seven columns">

							<?php if ( !dynamic_sidebar( 'Footer' ) ): ?><?php endif; ?>

						</div><!-- END .seven columns -->

					</div><!-- END .row -->

				</footer><!-- END #footer -->

			<?php } } } ?>

<?php bean_analytics(false);  wp_footer(); ?>

<!--<?php echo ''. BEAN_THEME_NAME .' WordPress Theme (ThemeBeans.com) with '. $wpdb->num_queries .' queries in '. timer_stop(0, 2) .' seconds'; ?>-->

</body>

</html>