<?php /* Portfolio Taxonomy */ ?>

<?php get_template_part( 'archive', 'portfolio' ); //PULL PORTFOLIO ARCHIVE ?>	