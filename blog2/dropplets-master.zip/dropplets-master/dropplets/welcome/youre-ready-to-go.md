# This is a Sample Post
- Dropplets
- dropplets
- 2020/02/02
- Posting
- published

Dropplets is all installed and ready to go. Life is good when there are no confusing databases or admins to worry about. Now all you have to do is publish your first post. To do that, just follow [these instructions](https://github.com/circa75/dropplets/blob/master/README.md). Or, if you already know how to use Dropplets, just publish your first post to delete this message.