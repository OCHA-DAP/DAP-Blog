<?php /* Sidebar */ ?>	
 
<div class="sidebar">    
  
	<?php dynamic_sidebar(); // DISPLAY THE SIDEBAR ?>
	
</div><!-- END .sidebar -->